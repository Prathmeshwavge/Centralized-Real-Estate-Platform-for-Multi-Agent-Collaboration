﻿using Microsoft.EntityFrameworkCore;
using real_estate.Models;

var builder = WebApplication.CreateBuilder(args);



// Add services to the container.
builder.Services.AddControllersWithViews(); 

builder.Services.AddHttpContextAccessor();
builder.Services.AddSession();


var provider = builder.Services.BuildServiceProvider();

var config = provider.GetRequiredService<IConfiguration>();

builder.Services.AddDbContext<real_estateDBContext>(Options => Options.UseSqlServer(config.GetConnectionString("DBConnection")));

var app = builder.Build();

// ✅ Add this one block
if (!LicenseCheck.IsValid())
{
    app.Run(async context =>
    {
        context.Response.StatusCode = 403;
        await context.Response.WriteAsync("License Expired. Please contact support.");
    });
    app.Run();
    return;
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
//app.UseStaticFiles();


app.UseSession();
//app.UseRouting();

//app.UseAuthorization();



app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
