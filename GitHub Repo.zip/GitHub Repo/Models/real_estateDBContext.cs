﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace real_estate.Models
{
    public partial class real_estateDBContext : DbContext
    {
        public real_estateDBContext()
        {
        }

        public real_estateDBContext(DbContextOptions<real_estateDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AdminLogin> AdminLogins { get; set; } = null!;
        public virtual DbSet<Association> Associations { get; set; } = null!;
        public virtual DbSet<AssociationAdmin> AssociationAdmins { get; set; } = null!;
        public virtual DbSet<BuyerRegistration> BuyerRegistrations { get; set; } = null!;
        public virtual DbSet<Contact> Contacts { get; set; } = null!;
        public virtual DbSet<Lead> Leads { get; set; } = null!;
        public virtual DbSet<PropertyListing> PropertyListings { get; set; } = null!;
        public virtual DbSet<SellerRegistration> SellerRegistrations { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AdminLogin>(entity =>
            {
                entity.ToTable("AdminLogin");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.AdminName).HasColumnName("admin_name");

                entity.Property(e => e.AdminPassword).HasColumnName("admin_password");
            });

            modelBuilder.Entity<Association>(entity =>
            {
                entity.ToTable("Association");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.City).HasColumnName("city");

                entity.Property(e => e.MembershipPlan).HasColumnName("membership_plan");

                entity.Property(e => e.PanCard).HasColumnName("pan_card");

                entity.Property(e => e.PaymentMethod).HasColumnName("payment_method");

                entity.Property(e => e.ReaCertificate).HasColumnName("rea_certificate");

                entity.Property(e => e.Sellerid).HasColumnName("sellerid");
            });

            modelBuilder.Entity<AssociationAdmin>(entity =>
            {
                entity.ToTable("AssociationAdmin");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.AdminName).HasColumnName("admin_name");

                entity.Property(e => e.AdminPassward).HasColumnName("admin_passward");
            });

            modelBuilder.Entity<BuyerRegistration>(entity =>
            {
                entity.ToTable("buyer_registration");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Address).HasColumnName("address");

                entity.Property(e => e.BuyerPhoto).HasColumnName("buyer_photo");

                entity.Property(e => e.EmailId).HasColumnName("email_id");

                entity.Property(e => e.MobileNo).HasColumnName("mobile_no");

                entity.Property(e => e.Name).HasColumnName("name");

                entity.Property(e => e.Password).HasColumnName("password");
            });

            modelBuilder.Entity<Contact>(entity =>
            {
                entity.ToTable("Contact");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.BuyerId).HasColumnName("buyer_id");

                entity.Property(e => e.Date)
                    .HasColumnType("datetime")
                    .HasColumnName("date");

                entity.Property(e => e.Description).HasColumnName("description");

                entity.Property(e => e.Remark).HasColumnName("remark");

                entity.Property(e => e.SellerId).HasColumnName("seller_id");
            });

            modelBuilder.Entity<Lead>(entity =>
            {
                entity.ToTable("Lead");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.BuyerId).HasColumnName("Buyer_id");

                entity.Property(e => e.Date)
                    .HasColumnType("datetime")
                    .HasColumnName("date");

                entity.Property(e => e.PropertyId).HasColumnName("Property_id");

                entity.Property(e => e.SellerId).HasColumnName("seller_id");
            });

            modelBuilder.Entity<PropertyListing>(entity =>
            {
                entity.ToTable("property_listing");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Area).HasColumnName("area");

                entity.Property(e => e.Bathrooms).HasColumnName("bathrooms");

                entity.Property(e => e.Bedrooms).HasColumnName("bedrooms");

                entity.Property(e => e.Certificate).HasColumnName("certificate");

                entity.Property(e => e.Description).HasColumnName("description");

                entity.Property(e => e.Floors).HasColumnName("floors");

                entity.Property(e => e.Location).HasColumnName("location");

                entity.Property(e => e.LocationUrl).HasColumnName("location_url");

                entity.Property(e => e.PerSqft).HasColumnName("Per_sqft");

                entity.Property(e => e.Photos).HasColumnName("photos");

                entity.Property(e => e.Price).HasColumnName("price");

                entity.Property(e => e.PropertyTitle).HasColumnName("property_title");

                entity.Property(e => e.PropertyType).HasColumnName("property_type");

                entity.Property(e => e.Rera).HasColumnName("RERA");

                entity.Property(e => e.ReraNo).HasColumnName("rera_no");

                entity.Property(e => e.SellerId).HasColumnName("seller_id");

                entity.Property(e => e.Sqft).HasColumnName("sqft");

                entity.Property(e => e.TotalFloors).HasColumnName("total_floors");
            });

            modelBuilder.Entity<SellerRegistration>(entity =>
            {
                entity.ToTable("seller_registration");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("id");

                entity.Property(e => e.Address).HasColumnName("address");

                entity.Property(e => e.Certificate).HasColumnName("certificate");

                entity.Property(e => e.EmailId).HasColumnName("email_id");

                entity.Property(e => e.MobileNo).HasColumnName("mobile_no");

                entity.Property(e => e.Name).HasColumnName("name");

                entity.Property(e => e.Password).HasColumnName("password");

                entity.Property(e => e.PaymentScreenshot).HasColumnName("payment_screenshot");

                entity.Property(e => e.RegType).HasColumnName("reg_type");

                entity.Property(e => e.ReraNo).HasColumnName("rera_no");

                entity.Property(e => e.ReraType).HasColumnName("rera_type");

                entity.Property(e => e.SellerPhoto).HasColumnName("seller_photo");

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .HasColumnName("status");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
