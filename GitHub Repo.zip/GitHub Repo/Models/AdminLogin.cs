﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class AdminLogin
    {
        public int Id { get; set; }
        public string? AdminName { get; set; }
        public string? AdminPassword { get; set; }
    }
}
