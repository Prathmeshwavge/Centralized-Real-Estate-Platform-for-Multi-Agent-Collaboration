﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class Association
    {
        public int Id { get; set; }
        public int? Sellerid { get; set; }
        public string? City { get; set; }
        public string? MembershipPlan { get; set; }
        public string? PaymentMethod { get; set; }
        public string? ReaCertificate { get; set; }
        public string? PanCard { get; set; }
        public string? Remark { get; set; }
    }
}
