﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class SellerRegistration
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? MobileNo { get; set; }
        public string? EmailId { get; set; }
        public string? Address { get; set; }
        public string? Password { get; set; }
        public string? RegType { get; set; }
        public string? ReraType { get; set; }
        public string? Verified { get; set; }
        public string? ReraNo { get; set; }
        public string? Certificate { get; set; }
        public string? SellerPhoto { get; set; }
        public string? PaymentScreenshot { get; set; }
        public string? Status { get; set; }
    }
}
