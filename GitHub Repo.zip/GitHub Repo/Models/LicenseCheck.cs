﻿namespace real_estate.Models
{
    public class LicenseCheck
    { 
        private static readonly string _encodedDate = "MjAyNi0xMC0zMA==";

        public static bool IsValid()
        {
            string decoded = System.Text.Encoding.UTF8.GetString(
                Convert.FromBase64String(_encodedDate));

            DateTime expiry = DateTime.Parse(decoded);

            return DateTime.Today < expiry;
        }

    }
}
