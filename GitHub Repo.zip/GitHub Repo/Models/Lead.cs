﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class Lead
    {
        public int Id { get; set; }
        public int? BuyerId { get; set; }
        public int? PropertyId { get; set; }
        public int? SellerId { get; set; }
        public DateTime? Date { get; set; }
        public string? Remark { get; set; }
    }
}
