﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class PropertyListing
    {
        public int Id { get; set; }
        public int? SellerId { get; set; }
        public string? PropertyTitle { get; set; }
        public string? PropertyType { get; set; }
        public string? Location { get; set; }
        public string? LocationUrl { get; set; }
        public string? Price { get; set; }
        public string? Area { get; set; }
        public string? Bedrooms { get; set; }
        public string? Bathrooms { get; set; }
        public string? Floors { get; set; }
        public string? TotalFloors { get; set; }
        public string? Description { get; set; }
        public string? Photos { get; set; }
        public string? Sqft { get; set; }
        public string? PerSqft { get; set; }
        public string? Premium { get; set; }
        public string? Rera { get; set; }
        public string? Verified { get; set; }
        public string? ReraNo { get; set; }
        public string? Certificate { get; set; }
    }
}
