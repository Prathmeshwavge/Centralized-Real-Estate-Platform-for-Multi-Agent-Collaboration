﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class BuyerRegistration
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? MobileNo { get; set; }
        public string? EmailId { get; set; }
        public string? Address { get; set; }
        public string? Password { get; set; }
        public string? BuyerPhoto { get; set; }
    }
}
