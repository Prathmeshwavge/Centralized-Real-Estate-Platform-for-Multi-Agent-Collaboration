﻿using System;
using System.Collections.Generic;

namespace real_estate.Models
{
    public partial class AssociationAdmin
    {
        public int Id { get; set; }
        public string? AdminName { get; set; }
        public string? AdminPassward { get; set; }
    }
}
