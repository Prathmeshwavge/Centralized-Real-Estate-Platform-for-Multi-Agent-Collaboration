﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using real_estate.Models;
using System.Data;

namespace real_estate.Controllers
{
    public class AdminAssociationController : Controller
    {
        private readonly real_estateDBContext DB;
        public AdminAssociationController(real_estateDBContext dB)
        {
            DB = dB;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard()
        {
            return View();
        }

    


        [HttpGet]
        public IActionResult Verifycontacts()
        {
            //var data = DB.Associations.ToList();
            //ViewBag.AssoData = data;


            //var result = from seller in DB.SellerRegistrations
            //             join assoc in DB.Associations
            //             on seller.Id equals assoc.Sellerid into sellerAssoc
            //             from association in sellerAssoc.DefaultIfEmpty()
            //             select new
            //             {
            //                 SellerId = seller.Id,
            //                 SellerName = seller.Name,
            //                 MobileNo = seller.MobileNo,
            //                 EmailId = seller.EmailId,
            //                 Address = seller.Address,
            //                 RegType = seller.RegType,
            //                 Verified = seller.Verified,
            //                 ReraNo = seller.ReraNo,
            //                 Certificate = seller.Certificate,
            //                 AssoId = association != null ? association.Id : 0,
            //                 City = association.City,
            //                 MembershipPlan = association.MembershipPlan,
            //                 PaymentMethod = association.PaymentMethod,
            //                 ReaCertificate = association.ReaCertificate,
            //                 PanCard = association.PanCard,
            //                 Remark=association.Remark
            //             };

            //var sellerAssociationList = result.ToList();



            var sellerAssociationList = (from seller in DB.SellerRegistrations
                                         join association in DB.Associations
                                         on seller.Id equals association.Sellerid
                                         select new
                                         {
                                             SellerId = seller.Id,
                                             SellerName = seller.Name,
                                             MobileNo = seller.MobileNo,
                                             EmailId = seller.EmailId,
                                             Address = seller.Address,
                                             RegType = seller.RegType,
                                             Verified = seller.Verified,
                                             ReraNo = seller.ReraNo,
                                             Certificate = seller.Certificate,
                                             AssoId = association.Id,
                                             City = association.City,
                                             MembershipPlan = association.MembershipPlan,
                                             PaymentMethod = association.PaymentMethod,
                                             ReaCertificate = association.ReaCertificate,
                                             PanCard = association.PanCard,
                                             Remark = association.Remark
                                         }).ToList();


            ViewBag.AssoData = sellerAssociationList;


            return View();
        }

        [HttpPost]
        public IActionResult Verifycontacts(int id, string btnAction)
        {
            try
            {
                var data = DB.Associations.FirstOrDefault(c => c.Id == id);

                if (data != null)
                {
                    if (btnAction == "Approve")
                    {
                        data.Remark = "Done";
                        TempData["AssoMessage"] = "Seller approved successfully!";
                    }
                    else if (btnAction == "Reject")
                    {
                        data.Remark = "Rejected";
                        TempData["AssoMessage"] = "Seller rejected successfully!";
                    }

                    DB.SaveChanges();
                }

                return RedirectToAction("Verifycontacts");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error updating property: " + ex.Message;
                return RedirectToAction("Verifycontacts");
            }
        }


        public IActionResult AssociationMemberProperties()
        {
            var data = DB.PropertyListings
                         .Where(p => DB.Associations
                                       .Any(a => a.Sellerid == p.SellerId))
                         .ToList();

            ViewBag.propertylistingData = data;
            return View();
        } 

        //[HttpGet]
        //public IActionResult VerifyProperties()
        //{
        //    var data = DB.PropertyListings
        //                 .Where(p => DB.Associations
        //                               .Any(a => a.Sellerid == p.SellerId))
        //                 .ToList();

        //    ViewBag.propertylistingData = data;
        //    return View();
        //}


        //[HttpPost]
        //public IActionResult Verifycontacts(int id)
        //{
        //    try
        //    {
        //        var data = DB.Associations.FirstOrDefault(c => c.Id == id);
        //        if (data != null)
        //        {
        //            data.Remark = "Done";
        //            DB.SaveChanges();
        //            TempData["AssoMessage"] = "Seller approved successfully!";
        //        }
        //        return RedirectToAction("Verifycontacts");
        //    }
        //    catch (Exception ex)
        //    {
        //        TempData["ErrorMessage"] = "Error approving lead: " + ex.Message;
        //        return RedirectToAction("Verifycontacts");
        //    }
        //}
        public IActionResult Logout()
        {

            HttpContext.Session.Remove("AdminAssoName");
            HttpContext.Session.Remove("AdminAssoPassword");
            return RedirectToAction("Index", "Home");

        }

    }
}
