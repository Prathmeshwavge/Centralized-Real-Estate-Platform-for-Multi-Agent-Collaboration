﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using real_estate.Models;
using System;

namespace real_estate.Controllers
{
    public class SellerController : Controller
    {

        private readonly real_estateDBContext DB;

        public SellerController(real_estateDBContext db)
        {
            DB = db;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard()
        {
            string userId = HttpContext.Session.GetString("Id"); 

            ViewBag.PropertyCount = DB.PropertyListings.Where(s=>s.SellerId==Convert.ToInt32(userId)).Count();

            ViewBag.LeadCount = DB.Leads.Where(s => s.SellerId == Convert.ToInt32(userId)).Count();

            ViewBag.AssoCount = DB.Associations.ToList().Count();
            return View();
        }
        
        [HttpGet]
        public IActionResult ProfileUpdate()
        {
            string userId = HttpContext.Session.GetString("Id");
            var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
            return View(data);
        }

        [HttpPost]
        public IActionResult ProfileUpdate(string txtid, string txtusername, string txtmobile, string txtemail, string txtaddress, string txtpassword, string ddltype,string ddlreratype,string txtrerano,IFormFile txtcertificate, IFormFile txtsellerphoto,string action)
        {
            string userId = HttpContext.Session.GetString("Id");
            var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId)); 

            if (action == "Update")
            {
                
                if (data != null)
                {
                    data.Name = txtusername;
                    data.MobileNo = txtmobile;
                    data.EmailId = txtemail;
                    data.Address = txtaddress;
                    data.Password = txtpassword;
                    data.ReraType = ddlreratype;
                    data.ReraNo = txtrerano;
                }

                string filecerPath = data.Certificate;

                if (txtcertificate != null && txtcertificate.Length > 0)
                {
                    // Define a folder path to store the uploaded files
                    string uploadcerFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadCertificate");

                    // Ensure the folder exists
                    if (!Directory.Exists(uploadcerFolder))
                    {
                        Directory.CreateDirectory(uploadcerFolder);
                    }

                    // Create a unique file name
                    string filecerName = $"{txtid}_{Path.GetFileName(txtcertificate.FileName)}";
                    filecerPath = Path.Combine(uploadcerFolder, filecerName);


                    // Save the file to the server
                    using (var stream = new FileStream(filecerPath, FileMode.Create))
                    {
                        txtcertificate.CopyTo(stream);
                    }

                    // Save only the relative path for database storage
                    //filePath = Path.Combine("Uploads", fileName);
                    filecerPath = Path.Combine(filecerName);
                }
                data.Certificate = filecerPath;




                string filesellerPath = data.SellerPhoto;

                if (txtsellerphoto != null && txtsellerphoto.Length > 0)
                {
                    // Define a folder path to store the uploaded files
                    string uploadsellerFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadSellerPhoto");

                    // Ensure the folder exists
                    if (!Directory.Exists(uploadsellerFolder))
                    {
                        Directory.CreateDirectory(uploadsellerFolder);
                    }

                    // Create a unique file name
                    string filesellerName = $"{txtid}_{Path.GetFileName(txtsellerphoto.FileName)}";
                    filesellerPath = Path.Combine(uploadsellerFolder, filesellerName);


                    // Save the file to the server
                    using (var stream = new FileStream(filesellerPath, FileMode.Create))
                    {
                        txtsellerphoto.CopyTo(stream);
                    }

                    // Save only the relative path for database storage
                    //filePath = Path.Combine("Uploads", fileName);
                    filesellerPath = Path.Combine(filesellerName);
                }
                data.SellerPhoto = filesellerPath;


                DB.SaveChanges();
                TempData["Msg"] = "Record updated successfully!";
            } 

            if(action== "Delete")
            {
                var isdelete = DB.PropertyListings.Any(l => l.SellerId == Convert.ToInt32(userId));

                if (isdelete)
                {
                    TempData["Msg"] = "Cannot delete. This Seller has added a property. Please delete the property first.";
                    return RedirectToAction("ProfileUpdate");
                }

                if (data != null)
                {
                    DB.SellerRegistrations.Remove(data);
                    DB.SaveChanges();
                    TempData["Msg"] = "Record deleted successfully!";
                }
            }
            return View(data);
        }

        [HttpGet]
        public IActionResult PropertyListing()
        {
            int maxid = 0; 

            if (DB.PropertyListings.Any())
            {
                maxid = DB.PropertyListings.Max(s => s.Id);
            }
            var newid = (maxid == 0) ? 1 : maxid + 1;
            ViewBag.Id = newid;

            string userId = HttpContext.Session.GetString("Id");
            return View();
        }

        [HttpPost] 
        public IActionResult PropertyListing(string txtid,string txtpropertytitle,string ddlpropertytype, string ddllocationtype,string txtlocation_url, string txtprice,string txtarea,string txtbedrooms,string txtbathrooms,string txtfloors,string txttotalfloors,string txtdescription, List<IFormFile> txtphtoto, IFormFile txtvideos,string txtsqft ,string txtpersqft, string ddlpremiumtype, string ddlreratype,string txtrerano,IFormFile txtcertificate)
        {
            int maxid = 0;
            if (DB.PropertyListings.Any())
            {
                maxid = DB.PropertyListings.Max(s => s.Id);
            }
            var newid = (maxid == 0) ? 1 : maxid + 1;
            ViewBag.Id = newid;

            string userId = HttpContext.Session.GetString("Id");
            PropertyListing propertyListing= new PropertyListing();


            propertyListing.Id = newid;
            propertyListing.SellerId = Convert.ToInt32(userId);
            propertyListing.PropertyTitle = txtpropertytitle;
            propertyListing.PropertyType = ddlpropertytype;
            propertyListing.Location = ddllocationtype;
            propertyListing.LocationUrl = txtlocation_url;
            propertyListing.Price= txtprice;
            propertyListing.Area= txtarea;
            propertyListing.Bedrooms= txtbedrooms;
            propertyListing.Bathrooms= txtfloors;
            propertyListing.Floors = txtfloors;
            propertyListing.TotalFloors= txttotalfloors;
            propertyListing.Description= txtdescription; 
            propertyListing.Sqft=txtsqft;
            propertyListing.PerSqft = txtpersqft;
            propertyListing.Premium = ddlpremiumtype;
            propertyListing.Rera= ddlreratype;
            propertyListing.Verified = "No";
            propertyListing.ReraNo = txtrerano;




            string filecerPath = null;

            if (txtcertificate != null && txtcertificate.Length > 0)
            {
                // Define a folder path to store the uploaded files
                string uploadcerFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadCertificate");

                // Ensure the folder exists
                if (!Directory.Exists(uploadcerFolder))
                {
                    Directory.CreateDirectory(uploadcerFolder);
                }

                // Create a unique file name
                string filecerName = $"{newid}_{Path.GetFileName(txtcertificate.FileName)}";
                filecerPath = Path.Combine(uploadcerFolder, filecerName);


                // Save the file to the server
                using (var stream = new FileStream(filecerPath, FileMode.Create))
                {
                    txtcertificate.CopyTo(stream);
                }

                // Save only the relative path for database storage
                //filePath = Path.Combine("Uploads", fileName);
                filecerPath = Path.Combine(filecerName);
            }







            //string filePath = null;

            //if (txtphtoto != null && txtphtoto.Length > 0)
            //{
            //    // Define a folder path to store the uploaded files
            //    string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadPhoto");

            //    // Ensure the folder exists
            //    if (!Directory.Exists(uploadFolder))
            //    {
            //        Directory.CreateDirectory(uploadFolder);
            //    }

            //    // Create a unique file name
            //    string fileName = $"{newid}_{Path.GetFileName(txtphtoto.FileName)}";
            //    filePath = Path.Combine(uploadFolder, fileName);


            //    // Save the file to the server
            //    using (var stream = new FileStream(filePath, FileMode.Create))
            //    {
            //        txtphtoto.CopyTo(stream);
            //    }

            //    // Save only the relative path for database storage
            //    //filePath = Path.Combine("Uploads", fileName);
            //    filePath = Path.Combine(fileName);
            //}



            List<string> filePaths = new List<string>();

            if (txtphtoto != null && txtphtoto.Count > 0)
            {
                string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadPhoto");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                foreach (var file in txtphtoto)
                {
                    string fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
                    string filePath = Path.Combine(uploadFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    // Save relative path or filename only
                    filePaths.Add(fileName);
                }
            }

            // Save the file paths (comma-separated or as JSON depending on your model)
            propertyListing.Photos = string.Join(",", filePaths);

            //propertyListing.Photos = filePath; 
            propertyListing.Certificate=filecerPath;

            DB.PropertyListings.Add(propertyListing);

            DB.SaveChanges();
            TempData["MsgProperty"] = "Record Inserted successfully!"; 

            return View();
        }

        [HttpGet]
        public IActionResult ViewPropertyListing()
        {
            string userId = HttpContext.Session.GetString("Id");
            //var data=DB.PropertyListings.ToList();
            var data = DB.PropertyListings.Where(p => p.SellerId == Convert.ToInt32(userId)).ToList();
            ViewBag.PropertyListing = data;
            return View();
        }


        [HttpGet]
        public IActionResult PropertyListingUpdate(int id)
        {
            var data = DB.PropertyListings.FirstOrDefault(c => c.Id == id);

            return View(data);
        }


        [HttpPost]
        public IActionResult PropertyListingUpdate(int txtid, string txtpropertytitle, string ddlpropertytype, string ddllocationtype, string txtlocation_url, string txtprice, string txtarea, string txtbedrooms, string txtbathrooms, string txtfloors, string txttotalfloors, string txtdescription, List<IFormFile> txtphtoto, IFormFile txtvideos, string txtsqft, string txtpersqft, string ddlpremiumtype, string ddlreratype,string txtrerano,IFormFile txtcertificate)
        {
            var data = DB.PropertyListings.FirstOrDefault(c => c.Id == txtid);
            string userId = HttpContext.Session.GetString("Id");
            if ( data != null)
            {
                data.SellerId = Convert.ToInt32(userId);
                data.PropertyTitle = txtpropertytitle;
                data.PropertyType = ddlpropertytype;
                data.Location = ddllocationtype;
                data.LocationUrl = txtlocation_url;
                data.Price = txtprice;
                data.Bedrooms = txtbedrooms;
                data.Bathrooms = txtbathrooms;
                data.Area = txtarea;
                data.Description = txtdescription;
                data.Floors = txtfloors;
                data.TotalFloors= txttotalfloors;
                data.Rera = ddlreratype;
                data.Premium = ddlpremiumtype;
                data.Sqft = txtsqft;
                data.PerSqft=txtpersqft;
                data.Verified = "No";
                data.ReraNo = txtrerano;

            }


            string filecerPath = data.Certificate;

            if (txtcertificate != null && txtcertificate.Length > 0)
            {
                // Define a folder path to store the uploaded files
                string uploadcerFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadCertificate");

                // Ensure the folder exists
                if (!Directory.Exists(uploadcerFolder))
                {
                    Directory.CreateDirectory(uploadcerFolder);
                }

                // Create a unique file name
                string filecerName = $"{txtid}_{Path.GetFileName(txtcertificate.FileName)}";
                filecerPath = Path.Combine(uploadcerFolder, filecerName);


                // Save the file to the server
                using (var stream = new FileStream(filecerPath, FileMode.Create))
                {
                    txtcertificate.CopyTo(stream);
                }

                // Save only the relative path for database storage
                //filePath = Path.Combine("Uploads", fileName);
                filecerPath = Path.Combine(filecerName);
            }

            

            List<string> filePaths = new List<string>();

            if (!string.IsNullOrEmpty(data.Photos))
            {
                filePaths = data.Photos.Split(',').ToList(); 
            }

            if (txtphtoto != null && txtphtoto.Count > 0)
            {
                string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadPhoto");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                foreach (var file in txtphtoto)
                {
                    string fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
                    string filePath = Path.Combine(uploadFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    // Save relative path or filename only
                    filePaths.Add(fileName);
                }
            }

            // Save the file paths (comma-separated or as JSON depending on your model)
            data.Photos = string.Join(",", filePaths);


            //string filePath = data.Photos; // Retain the old file path by default

            //if (txtphtoto != null && txtphtoto.Length > 0)
            //{
            //    // Define the folder path
            //    string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadPhoto");

            //    // Ensure the folder exists
            //    if (!Directory.Exists(uploadFolder))
            //    {
            //        Directory.CreateDirectory(uploadFolder);
            //    }

            //    // Create a unique file name
            //    string fileName = $"{txtid}_{Path.GetFileName(txtphtoto.FileName)}";
            //    filePath = Path.Combine(uploadFolder, fileName);

            //    // Save the file to the server
            //    using (var stream = new FileStream(filePath, FileMode.Create))
            //    {
            //        txtphtoto.CopyTo(stream);
            //    }

            //    // Save only the relative path for database storage
            //    filePath = fileName; // Keep only the file name
            //}

            //// Assign the final file path to the data model
            //data.Photos = filePath;
            data.Certificate=filecerPath;



            DB.SaveChanges();
            TempData["MsgUpdate"] = "Record updated successfully!";
            return View(data);
        }

        
        public IActionResult PropertyListingDelete(int id)
        {
            var isPropertyInLead = DB.Leads.Any(l => l.PropertyId == id);

            if (isPropertyInLead)
            {
                TempData["MsgDelete"] = "You cannot delete this property because a buyer has already visited or shown interest. Please delete the associated lead first.";
                return RedirectToAction("ViewPropertyListing");
            }

            var property = DB.PropertyListings.FirstOrDefault(p => p.Id == id);
            if (property != null)
            {
                DB.PropertyListings.Remove(property);
                DB.SaveChanges();
            } 

            TempData["MsgDelete"] = "Property Deleted Sucessfully!";
            return RedirectToAction("ViewPropertyListing"); 
        }

        [HttpGet]
        public IActionResult LeadManagement()
        {
            //string userId = HttpContext.Session.GetString("Id");

            int userId = int.Parse(HttpContext.Session.GetString("Id"));

            var leads = (from l in DB.Leads
                         where l.SellerId == userId
                         join b in DB.BuyerRegistrations on l.BuyerId equals b.Id into buyers
                         from b in buyers.DefaultIfEmpty()
                         join s in DB.SellerRegistrations on l.SellerId equals s.Id into sellers
                         from s in sellers.DefaultIfEmpty()
                         join p in DB.PropertyListings on l.PropertyId equals p.Id into properties
                         from p in properties.DefaultIfEmpty()
                         select new
                         {
                             LeadId = l.Id,
                             BuyerName = b.Name,
                             BuyerMobile = b.MobileNo,
                             BuyerEmail = b.EmailId,
                             BuyerAddress = b.Address,
                             SellerName = s.Name,
                             SellerMobile = s.MobileNo,
                             PropertyId = l.PropertyId,
                             PropertyTitle = p.PropertyTitle,
                             PropertyType = p.PropertyType,
                             PropertyLocation = p.Location,
                             Propertyprice = p.Price,
                             PropertyRera = p.Rera,
                             Remark = l.Remark,
                             Date=l.Date
                         }).ToList();

            ViewBag.Leads = leads;

            return View();

        }



        [HttpPost]
        public IActionResult LeadManagement(int id)
        {
            try
            {
                var lead = DB.Leads.FirstOrDefault(c => c.Id == id);
                if (lead != null)
                {
                    lead.Remark = "Done";
                    DB.SaveChanges();
                    TempData["SuccessMessage"] = "Lead approved successfully!";
                }
                return RedirectToAction("LeadManagement");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error approving lead: " + ex.Message;
                return RedirectToAction("LeadManagement");
            }
        }


        [HttpGet]
        public IActionResult RERERegister()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ViewFeedback()
        {
            return View();
        }

        //[HttpGet]
        //public IActionResult Association()
        //{
        //    string userId = HttpContext.Session.GetString("Id");
        //    var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
        //    ViewBag.name = data.Name;
        //    ViewBag.mobile = data.MobileNo;
        //    ViewBag.email = data.EmailId;
        //    ViewBag.Regttype = data.RegType;
        //    ViewBag.Rerano = data.ReraNo;
        //    ViewBag.Verified = data.Verified;
            


        //    return View();

        //}


        //[HttpPost]
        //public IActionResult Association(string txtcities, string ddlmembershipPlan, string ddlpaymentMethod, IFormFile txtregistrationCert,IFormFile txtpanCard)
        //{
        //    int maxid = 0;
        //    if (DB.Leads.Any())
        //    {
        //        maxid = DB.Leads.Max(s => s.Id);
        //    }
        //    var newid = (maxid == 0) ? 1 : maxid + 1;
        //    ViewBag.Id = newid;

        //    string userId = HttpContext.Session.GetString("Id");
        //    var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
        //    ViewBag.name = data.Name;
        //    ViewBag.mobile = data.MobileNo;
        //    ViewBag.email = data.EmailId;
        //    ViewBag.Regttype = data.RegType;
        //    ViewBag.Rerano = data.ReraNo;
        //    ViewBag.Verified = data.Verified;

        //    Association association = new Association();
        //    association.Id = newid;
        //    association.Sellerid = Convert.ToInt32(userId);
        //    association.City = txtcities;
        //    association.MembershipPlan=ddlmembershipPlan;
        //    association.PaymentMethod = ddlpaymentMethod;


        //    string filecerPath = null;

        //    if (txtregistrationCert != null && txtregistrationCert.Length > 0)
        //    {
        //        // Define a folder path to store the uploaded files
        //        string uploadcerFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "AssociationUpload");

        //        // Ensure the folder exists
        //        if (!Directory.Exists(uploadcerFolder))
        //        {
        //            Directory.CreateDirectory(uploadcerFolder);
        //        }

        //        // Create a unique file name
        //        string filecerName = $"{newid}_{Path.GetFileName(txtregistrationCert.FileName)}";
        //        filecerPath = Path.Combine(uploadcerFolder, filecerName);


        //        // Save the file to the server
        //        using (var stream = new FileStream(filecerPath, FileMode.Create))
        //        {
        //            txtregistrationCert.CopyTo(stream);
        //        }

        //        // Save only the relative path for database storage
        //        //filePath = Path.Combine("Uploads", fileName);
        //        filecerPath = Path.Combine(filecerName);
        //    }


        //    string filePath = null;

        //    if (txtpanCard != null && txtpanCard.Length > 0)
        //    {
        //        // Define a folder path to store the uploaded files
        //        string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "AssociationUpload");

        //        // Ensure the folder exists
        //        if (!Directory.Exists(uploadFolder))
        //        {
        //            Directory.CreateDirectory(uploadFolder);
        //        }

        //        // Create a unique file name
        //        string fileName = $"{newid}_{Path.GetFileName(txtpanCard.FileName)}";
        //        filePath = Path.Combine(uploadFolder, fileName);


        //        // Save the file to the server
        //        using (var stream = new FileStream(filePath, FileMode.Create))
        //        {
        //            txtpanCard.CopyTo(stream);
        //        }

        //        // Save only the relative path for database storage
        //        //filePath = Path.Combine("Uploads", fileName);
        //        filePath = Path.Combine(fileName);
        //    }


        //   association.PanCard = filePath;
        //   association.ReaCertificate = filecerPath;

        //   return View();

        //}





        [HttpGet]
        public IActionResult Association()
        {
            string userId = HttpContext.Session.GetString("Id");
            if (string.IsNullOrEmpty(userId))
            {
                return RedirectToAction("Login"); // Redirect if user is not logged in
            }

            var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
            if (data == null)
            {
                return NotFound(); // Handle if user data is not found
            }

            ViewBag.name = data.Name;
            ViewBag.mobile = data.MobileNo;
            ViewBag.email = data.EmailId;
            ViewBag.Regttype = data.RegType;
            ViewBag.Rerano = data.ReraNo;
            ViewBag.Verified = data.Verified;

            return View();
        }

        [HttpPost]
        public IActionResult Association(string txtcities, string ddlmembershipPlan, string ddlpaymentMethod, IFormFile txtregistrationCert, IFormFile txtpanCard)
        {
            string userId = HttpContext.Session.GetString("Id");
            if (string.IsNullOrEmpty(userId))
            {
                return RedirectToAction("Login");
            }

            int maxid = DB.Associations.Any() ? DB.Associations.Max(s => s.Id) : 0;
            var newid = maxid + 1;

            var sellerData = DB.SellerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
            if (sellerData == null)
            {
                return NotFound();
            }

            //string filecerPath = null, filePath = null;
            //string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "AssociationUpload");
            //if (!Directory.Exists(uploadFolder))
            //{
            //    Directory.CreateDirectory(uploadFolder);
            //}

            string filecerPath = null;

            if (txtregistrationCert != null && txtregistrationCert.Length > 0)
            {
                // Define a folder path to store the uploaded files
                string uploadcerFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "AssociationUpload");

                // Ensure the folder exists
                if (!Directory.Exists(uploadcerFolder))
                {
                    Directory.CreateDirectory(uploadcerFolder);
                }

                // Create a unique file name
                string filecerName = $"{newid}_{Path.GetFileName(txtregistrationCert.FileName)}";
                filecerPath = Path.Combine(uploadcerFolder, filecerName);


                // Save the file to the server
                using (var stream = new FileStream(filecerPath, FileMode.Create))
                {
                    txtregistrationCert.CopyTo(stream);
                }

                // Save only the relative path for database storage
                //filePath = Path.Combine("Uploads", fileName);
                filecerPath = Path.Combine(filecerName);
            }


            string filePath = null;

            if (txtpanCard != null && txtpanCard.Length > 0)
            {
                // Define a folder path to store the uploaded files
                string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "AssociationUpload");

                // Ensure the folder exists
                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                // Create a unique file name
                string fileName = $"{newid}_{Path.GetFileName(txtpanCard.FileName)}";
                filePath = Path.Combine(uploadFolder, fileName);


                // Save the file to the server
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    txtpanCard.CopyTo(stream);
                }

                // Save only the relative path for database storage
                //filePath = Path.Combine("Uploads", fileName);
                filePath = Path.Combine(fileName);
            }


            Association association = new Association
            {
                Id = newid,
                Sellerid = Convert.ToInt32(userId),
                City = txtcities,
                MembershipPlan = ddlmembershipPlan,
                PaymentMethod = ddlpaymentMethod,
                PanCard = filePath,
                ReaCertificate = filecerPath,
                Remark = "Pending"
            };

            DB.Associations.Add(association);
            DB.SaveChanges();


            TempData["MsgAssociation"] = "Record updated successfully!";
            return RedirectToAction("Association"); // Redirect to prevent form resubmission
        }


        public IActionResult ViewAssociationmember()
        {
            var data = (from a in DB.Associations
                        join s in DB.SellerRegistrations on a.Sellerid equals s.Id
                        select new
                        {
                            a.Id,
                            s.Name,
                            s.MobileNo,
                            s.EmailId,
                            s.RegType,
                            a.City,
                            a.MembershipPlan,
                            a.PaymentMethod
                        }).ToList();

            // Count members based on RegType
            var regTypeCounts = data.GroupBy(x => x.RegType)
                                    .Select(g => new { RegType = g.Key, Count = g.Count() })
                                    .ToList();

            ViewBag.AssociationMembers = data;
            ViewBag.RegTypeCounts = regTypeCounts; 


            ViewBag.Sellercount = data.Where(s=>s.RegType=="Builder").ToList().Count();
            ViewBag.Sellercount1 = data.Where(s => s.RegType == "Builder").ToList();
            ViewBag.Buyercount = data.Where(s => s.RegType == "Broker").ToList().Count();
            ViewBag.Buyercount1 = data.Where(s => s.RegType == "Broker").ToList();
            return View();
        }


        [HttpGet]
        public IActionResult FeesPaid()
        {
            return View();
        }

        //[HttpGet]
        //public IActionResult ViewAssociationProperties()
        //{
        //    var data = DB.PropertyListings.ToList();
        //    ViewBag.PropertyListing = data;
        //    return View();
        //}


        //[HttpGet]
        //public IActionResult ViewAssociationProperties()
        //{
        //    var data = DB.PropertyListings
        //                 .Where(p => DB.Associations
        //                               .Any(a => a.Sellerid == p.SellerId))


        //                 .ToList();

        //    ViewBag.PropertyListing = data;
        //    return View();
        //}





        [HttpGet]
        public IActionResult AssociationLead(int id)
        {
            var data = (from property in DB.PropertyListings
                        join seller in DB.SellerRegistrations
                        on property.SellerId equals seller.Id
                        where property.Id == id
                        select new
                        {
                            Property = property,
                            Seller = seller
                        }).FirstOrDefault();

            if (data != null)
            {
                ViewBag.PropertyId = data.Property.Id;
                ViewBag.PropertyTitle = data.Property.PropertyTitle;
                ViewBag.PropertyType = data.Property.PropertyType;
                ViewBag.Location = data.Property.Location;
                ViewBag.LocationUrl = data.Property.LocationUrl;
                ViewBag.Price = data.Property.Price;
                ViewBag.Area = data.Property.Area;
                ViewBag.Bedrooms = data.Property.Bedrooms;
                ViewBag.Bathrooms = data.Property.Bathrooms;
                ViewBag.Floors = data.Property.Floors;
                ViewBag.TotalFloors = data.Property.TotalFloors;
                ViewBag.Description = data.Property.Description;
                ViewBag.Photos = data.Property.Photos;
                ViewBag.Sqft = data.Property.Sqft;
                ViewBag.Premium = data.Property.Premium;
                ViewBag.Rera = data.Property.Rera;
                ViewBag.Verified = data.Property.Verified;
                ViewBag.ReraNo = data.Property.ReraNo;
                ViewBag.Certificate = data.Property.Certificate;

                // Seller Information 
                ViewBag.SellerId = data.Seller.Id;
                ViewBag.SellerName = data.Seller.Name;
                ViewBag.SellerMobileNo = data.Seller.MobileNo;
                ViewBag.SellerEmailId = data.Seller.EmailId;
                ViewBag.SellerAddress = data.Seller.Address;
                ViewBag.SellerRegType = data.Seller.RegType;
                ViewBag.SellerReraType = data.Seller.ReraType;
                ViewBag.SellerVerified = data.Seller.Verified;
                ViewBag.SellerReraNo = data.Seller.ReraNo;
                ViewBag.SellerCertificate = data.Seller.Certificate;
            }
            else
            {
                ViewBag.Message = "No Property Found!";
            }

            return View();
        }



        //[HttpPost]
        //public IActionResult ViewAssociationProperties(int id)
        //{
        //    var data = DB.PropertyListings.ToList();

        //    return View(data); 
        //}



        [HttpGet]
        public IActionResult ViewAssociationProperties()
        {
            // Use "Id" to match your other methods
            string userId = HttpContext.Session.GetString("Id");

            //if (string.IsNullOrEmpty(userId))
            //{
            //    TempData["Error"] = "Please login first";
            //    return RedirectToAction("Login", "Seller");
            //}
            if (string.IsNullOrEmpty(userId))
            {
                return RedirectToAction("SellerLogin", "Home");
            }

            int loggedInSellerId = Convert.ToInt32(userId);

            // Check if the logged-in seller is a member of any association
            var isMember = DB.Associations
                             .Any(a => a.Sellerid == loggedInSellerId);

            if (!isMember)
            {
                // Seller is not a member - show empty list or message
                ViewBag.PropertyListing = new List<PropertyListing>();
                ViewBag.Message = "You must be an association member to view properties.";
                return View();
            }

            // Seller is a member - show all properties from association members
            var data = DB.PropertyListings
                         .Where(p => DB.Associations
                                       .Any(a => a.Sellerid == p.SellerId))
                         .ToList();

            ViewBag.PropertyListing = data;
            ViewBag.Message = null;
            return View();
        }

        [HttpGet]
        public IActionResult LeadManagementDelete(int id)
        {
            var data = DB.Leads.FirstOrDefault(p => p.Id == id);
            if (data != null)
            {
                DB.Leads.Remove(data);
                DB.SaveChanges();
            }

            TempData["MsgLeadDelete"] = "Record Deleted successfully!";
            return RedirectToAction("LeadManagement");
           // return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("SellerEmail");
            HttpContext.Session.Remove("SellerPassword");
            return RedirectToAction("Index", "Home");
        }
    }
}
