﻿using Microsoft.AspNetCore.Mvc;
using real_estate.Models;
using System;

namespace real_estate.Controllers
{
    public class AdminController : Controller
    {
        private readonly real_estateDBContext DB;
        public AdminController(real_estateDBContext dB)
        {
            DB = dB;
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard()
        {
            return View();
        }

        //[HttpGet]
        //public IActionResult ViewAllSeller()
        //{
        //    var data = DB.SellerRegistrations.ToList();
        //    ViewBag.SellerData = data;
        //    return View();
        //} 


        [HttpGet]
        public IActionResult VerifySeller()
        {
            var data = DB.SellerRegistrations.ToList();
            ViewBag.SellerData = data;
            return View();
        } 


        //[HttpPost]
        //public IActionResult VerifySeller(string txtstatus, int id)
        //{
        //    var data = DB.SellerRegistrations.ToList();
        //    ViewBag.propertylistingData = data;


        //    var property = DB.SellerRegistrations.FirstOrDefault(c => c.Id == id);
        //    if (property != null)
        //    {
        //        property.Verified = "Yes";
        //    }
        //    DB.SaveChanges();
        //    TempData["MsgSeller"] = "Seller Approval successfully!";
        //    return RedirectToAction("VerifySeller");
        //}



        [HttpPost]
        public IActionResult VerifySeller(int id,string btnAction)
        {
            //try
            //{
            //    var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == id);
            //    if (data != null)
            //    {
            //        data.Verified = "Yes";
            //        DB.SaveChanges();
            //        TempData["MsgSeller"] = "Seller approval successfully!";
            //    }
            //    return RedirectToAction("VerifySeller");
            //}
            //catch (Exception ex)
            //{
            //    TempData["ErrorMessage"] = "Error approving lead: " + ex.Message;
            //    return RedirectToAction("VerifySeller");
            //}


            try
            {
                var data = DB.SellerRegistrations.FirstOrDefault(c => c.Id == id);

                if (data != null)
                {
                    if (btnAction == "Approve")
                    {
                        data.Verified = "Yes";
                        data.Status = "Done";
                        TempData["MsgSeller"] = "Seller approved successfully!";
                    }
                    else if (btnAction == "Reject")
                    {
                        data.Verified = "Rejected";
                        TempData["MsgSeller"] = "Seller rejected successfully!";
                    }

                    DB.SaveChanges();
                }

                return RedirectToAction("VerifySeller");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error updating property: " + ex.Message;
                return RedirectToAction("VerifySeller");
            }
        }
        //[HttpGet]
        //public IActionResult ViewProperties()
        //{
        //    var data = DB.PropertyListings.ToList();
        //    ViewBag.propertylistingData = data;
        //    return View();
        //}

        [HttpGet]
        public IActionResult VerifyProperties()
        {
            var data = DB.PropertyListings.ToList();
            ViewBag.propertylistingData = data;
            return View();
        }

        //[HttpPost]
        //public IActionResult VerifyProperties(string txtstatus,int id)
        //{
        //    var data = DB.PropertyListings.ToList();
        //    ViewBag.propertylistingData = data;


        //    var property = DB.PropertyListings.FirstOrDefault(c => c.Id == id); 
        //    if(property != null)
        //    {
        //        property.Verified = "Yes";
        //    } 
        //    DB.SaveChanges();
        //    TempData["MsgProperty"] = "Property Approval successfully!";
        //    return RedirectToAction("VerifyProperties");
        //}


        [HttpPost]
        public IActionResult VerifyProperties(int id,string btnAction)
        {
            //try
            //{   
                
            //    var data = DB.PropertyListings.FirstOrDefault(c => c.Id == id); 
                
            //    if (data != null)
            //    {
            //        data.Verified = "Yes";
            //        DB.SaveChanges();
            //        TempData["MsgProperty"] = "Seller approval successfully!";
            //    }
            //    return RedirectToAction("VerifyProperties");
            //}
            //catch (Exception ex)
            //{
            //    TempData["ErrorMessage"] = "Error approving lead: " + ex.Message;
            //    return RedirectToAction("VerifyProperties");
            //}

            try
            {
                var data = DB.PropertyListings.FirstOrDefault(c => c.Id == id);

                if (data != null)
                {
                    if (btnAction == "Approve")
                    {
                        data.Verified = "Yes";
                        TempData["MsgProperty"] = "Property approved successfully!";
                    }
                    else if (btnAction == "Reject")
                    {
                        data.Verified = "Rejected";
                        TempData["MsgProperty"] = "Property rejected successfully!";
                    }

                    DB.SaveChanges();
                }

                return RedirectToAction("VerifyProperties");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error updating property: " + ex.Message;
                return RedirectToAction("VerifyProperties");
            }
        }

        [HttpGet]
        public IActionResult VerifyContacts()
        {
            var result = from contact in DB.Contacts
                         join buyer in DB.BuyerRegistrations
                         on contact.BuyerId equals buyer.Id into buyerGroup
                         from buyer in buyerGroup.DefaultIfEmpty() // Handle cases where no buyer exists
                         join seller in DB.SellerRegistrations
                         on contact.SellerId equals seller.Id into sellerGroup
                         from seller in sellerGroup.DefaultIfEmpty() // Handle cases where no seller exists
                         select new
                         {
                             ContactId = contact.Id,
                             contact.Description,
                             contact.Date,
                             contact.Remark,

                             // Buyer Details
                             contact.BuyerId,
                             BuyerName = buyer.Name,
                             BuyerMobile = buyer.MobileNo,
                             BuyerEmail = buyer.EmailId,
                             BuyerAddress = buyer.Address,

                             // Seller Details
                             contact.SellerId,
                             SellerName = seller.Name,
                             SellerMobile = seller.MobileNo,
                             SellerEmail = seller.EmailId,
                             SellerAddress = seller.Address,
                             SellerRegType = seller.RegType,
                             SellerVerified = seller.Verified,
                             SellerReraNo = seller.ReraNo,
                             SellerCertificate = seller.Certificate
                         };

            var contactList = result.ToList();
            ViewBag.ContactData = contactList;
            return View();


           // return View();
        }


        [HttpPost]
        public IActionResult VerifyContacts(int id,string btnAction)
        {
            //try
            //{
            //    var data = DB.Contacts.FirstOrDefault(c => c.Id == id);
            //    if (data != null)
            //    {
            //        data.Remark = "Done";
            //        DB.SaveChanges();
            //        TempData["MsgContact"] = "Contacts approval successfully!";
            //    }
            //    return RedirectToAction("VerifyContacts");
            //}
            //catch (Exception ex)
            //{
            //    TempData["ErrorMessage"] = "Error approving lead: " + ex.Message;
            //    return RedirectToAction("VerifyContacts");
            //}

            try
            {
                var data = DB.Contacts.FirstOrDefault(c => c.Id == id);

                if (data != null)
                {
                    if (btnAction == "Approve")
                    {
                        data.Remark = "Done";
                        TempData["MsgContact"] = "Contacts approved successfully!";
                    }
                    else if (btnAction == "Reject")
                    {
                        data.Remark = "Rejected";
                        TempData["MsgContact"] = "Contacts rejected successfully!";
                    }

                    DB.SaveChanges();
                }

                return RedirectToAction("Verifycontacts");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error updating property: " + ex.Message;
                return RedirectToAction("Verifycontacts");
            }
        }


        public IActionResult Logout()
        {

            HttpContext.Session.Remove("AdminName");
            HttpContext.Session.Remove("AdminPassword");
            return RedirectToAction("Index", "Home");

        }
    }
}
