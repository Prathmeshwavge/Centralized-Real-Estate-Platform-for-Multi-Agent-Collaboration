﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using real_estate.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace real_estate.Controllers
{
    public class BuyerController : Controller
    {
        private readonly real_estateDBContext DB;
        public BuyerController(real_estateDBContext dB)
        {
            DB = dB;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Dashboard()
        {
            string userId = HttpContext.Session.GetString("Id");

            ViewBag.PropertyCount = DB.PropertyListings.ToList().Count();

            ViewBag.LeadCount = DB.Leads.ToList().Count();

            return View();
        }

        //   [HttpGet]
        //   public IActionResult VerifiedProperties()
        //   {
        //       var propertyCounts = DB.PropertyListings
        //.GroupBy(p => new { p.PropertyType })
        //.Select(g => new { PropertyType = g.Key.PropertyType, Count = g.Count() })
        //.ToDictionary(x => x.PropertyType, x => x.Count);


        //       ViewBag.PropertyCounts = propertyCounts;
        //       return View();
        //   }


        //   [HttpPost]
        //   public IActionResult VerifiedProperties(string propertyType, string location, string keyword)
        //   {
        //       var query = DB.PropertyListings.AsQueryable();

        //       // Apply Filters
        //       if (!string.IsNullOrEmpty(propertyType))
        //       {
        //           query = query.Where(p => p.PropertyType == propertyType);
        //       }

        //       if (!string.IsNullOrEmpty(location))
        //       {
        //           query = query.Where(p => p.Location == location);
        //       }

        //       if (!string.IsNullOrEmpty(keyword))
        //       {
        //           query = query.Where(p => p.Price.Contains(keyword));
        //       }

        //       // Group by PropertyType and count records
        //       var propertyCounts = query.GroupBy(p => p.PropertyType)
        //           .Select(g => new { PropertyType = g.Key, Count = g.Count() })
        //           .ToDictionary(x => x.PropertyType, x => x.Count);

        //       ViewBag.PropertyCounts = propertyCounts;

        //       return View();
        //   }

        [HttpGet]
        public IActionResult VerifiedProperties(string propertyType, string location, string keyword)
        {
            var query = DB.PropertyListings.AsQueryable();

            // Apply Filters from query string
            if (!string.IsNullOrEmpty(propertyType))
            {
                query = query.Where(p => p.PropertyType == propertyType);
            }

            if (!string.IsNullOrEmpty(location))
            {
                query = query.Where(p => p.Location == location);
            }

            if (!string.IsNullOrEmpty(keyword))
            {
                query = query.Where(p => p.PropertyTitle.Contains(keyword) ||
                                       p.Description.Contains(keyword) ||
                                       p.Price.Contains(keyword));
            }

            // Group by PropertyType and count records
            var propertyCounts = query
                .GroupBy(p => p.PropertyType)
                .Select(g => new { PropertyType = g.Key, Count = g.Count() })
                .ToDictionary(x => x.PropertyType, x => x.Count);

            ViewBag.PropertyCounts = propertyCounts;
            ViewBag.SelectedPropertyType = propertyType;
            ViewBag.SelectedLocation = location;
            ViewBag.SearchKeyword = keyword;

            return View();
        }


        [HttpGet]
        public IActionResult VerifiedViewProperties(string propertyType, string location, string keyword)
        {
            var query = DB.PropertyListings.AsQueryable();

            if (!string.IsNullOrEmpty(propertyType))
            {
                query = query.Where(p => p.PropertyType == propertyType);
            }

            if (!string.IsNullOrEmpty(location))
            {
                query = query.Where(p => p.Location == location);
            }

            if (!string.IsNullOrEmpty(keyword))
            {
                query = query.Where(p => p.Price.Contains(keyword) ||
                                         p.PropertyTitle.Contains(keyword) ||
                                         p.Description.Contains(keyword));
            }

            ViewBag.Properties = query.ToList();



            var recommendedProperties = DB.PropertyListings
      //.Where(p => !string.IsNullOrEmpty(location) && p.Location == location)
      .ToList();

            //ViewBag.Properties = properties;
            ViewBag.RecommendedProperties = recommendedProperties;




       //     var recommendedProperties = DB.PropertyListings
       //.Where(p => !string.IsNullOrEmpty(location) && p.Location == location &&
       //            (string.IsNullOrEmpty(propertyType) || p.PropertyType != propertyType))
       //.ToList();

       //    // ViewBag.Properties = properties;
       //     ViewBag.RecommendedProperties = recommendedProperties;

            return View();
        }



        //[HttpPost] // Use POST for actions that modify data
        //public IActionResult VerifiedViewProperties(string propertyType, int id, string action, string location, string keyword)
        //{
        //    var query = DB.PropertyListings.AsQueryable();

        //    if (!string.IsNullOrEmpty(propertyType))
        //    {
        //        query = query.Where(p => p.PropertyType == propertyType);
        //    }

        //    if (!string.IsNullOrEmpty(location))
        //    {
        //        query = query.Where(p => p.Location == location);
        //    }

        //    if (!string.IsNullOrEmpty(keyword))
        //    {
        //        query = query.Where(p => p.Price.Contains(keyword) ||
        //                                 p.PropertyTitle.Contains(keyword) ||
        //                                 p.Description.Contains(keyword));
        //    }

        //    ViewBag.Properties = query.ToList();

        //    // Generate new Lead ID
        //    int maxid = DB.Leads.Any() ? DB.Leads.Max(s => s.Id) : 0;
        //    int newid = maxid + 1;

        //    string buyerId = HttpContext.Session.GetString("BuyerId");

        //    if (!string.IsNullOrEmpty(buyerId) && int.TryParse(buyerId, out int buyerIdInt))
        //    {
        //        Lead lead = new Lead
        //        {
        //            Id = newid,
        //            BuyerId = buyerIdInt,
        //            PropertyId = id,
        //            Remark = "Pending"
        //        };

        //        DB.Leads.Add(lead);
        //        DB.SaveChanges();
        //        TempData["LeadMsg"] = "Lead added successfully!";
        //    }

        //    return RedirectToAction("VerifiedProperties");
        //}



















        //[HttpGet]
        //public IActionResult VerifiedViewProperties(string propertyType)
        //{
        //    var data = (from p in DB.PropertyListings
        //                join s in DB.SellerRegistrations on p.SellerId equals s.Id
        //                where p.PropertyType == propertyType && p.Verified == "Yes" && s.Verified == "Yes"
        //                select new
        //                {
        //                    p.Id,
        //                    p.PropertyTitle,
        //                    p.PropertyType,
        //                    p.Location,
        //                    p.Price,
        //                    p.Area,
        //                    p.Bedrooms,
        //                    p.Bathrooms,
        //                    p.Floors,
        //                    p.TotalFloors,
        //                    p.Description,
        //                    p.Photos,
        //                    p.Sqft,
        //                    p.Premium,
        //                    p.Rera,
        //                    SellerName = s.Name,
        //                    SellerMobile = s.MobileNo,
        //                    SellerEmail = s.EmailId,
        //                    SellerAddress = s.Address
        //                }).ToList();

        //    ViewBag.Properties = data;
        //    return View();
        //}

        [HttpGet]
        public IActionResult BuyerProfileUpdate()
        {
            string userId = HttpContext.Session.GetString("BuyerId");
            var data = DB.BuyerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
            return View(data);
           
        }

        [HttpPost]
        public IActionResult BuyerProfileUpdate(string txtid,string txtusername, string txtmobile, string txtemail, string txtaddress,string txtpassword, IFormFile txtbuyerphoto,string action)
        { 
           

            string userId = HttpContext.Session.GetString("BuyerId");
            var data = DB.BuyerRegistrations.FirstOrDefault(c => c.Id == Convert.ToInt32(userId));
            if (action == "Update")
            {
                if (data != null)
                {
                    data.Name = txtusername;
                    data.MobileNo = txtmobile;
                    data.EmailId = txtemail;
                    data.Address = txtaddress;
                    data.Password = txtpassword;

                }



                string filePath = data.BuyerPhoto;

                if (txtbuyerphoto != null && txtbuyerphoto.Length > 0)
                {
                    // Define a folder path to store the uploaded files
                    string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "UploadBuyerPhoto");

                    // Ensure the folder exists
                    if (!Directory.Exists(uploadFolder))
                    {
                        Directory.CreateDirectory(uploadFolder);
                    }

                    // Create a unique file name
                    string fileName = $"{txtid}_{Path.GetFileName(txtbuyerphoto.FileName)}";
                    filePath = Path.Combine(uploadFolder, fileName);


                    // Save the file to the server
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        txtbuyerphoto.CopyTo(stream);
                    }

                    // Save only the relative path for database storage
                    //filePath = Path.Combine("Uploads", fileName);
                    filePath = Path.Combine(fileName);
                }
                data.BuyerPhoto = filePath;
                DB.SaveChanges();
                TempData["BuyerMsg"] = "Record updated successfully!";
            }
            if (action == "Delete")
            {
                var isdelete = DB.Leads.Any(l => l.BuyerId == Convert.ToInt32(userId));

                if (isdelete)
                {
                    TempData["Msg"] = "Cannot delete. This Buyer Book Property.";
                    return RedirectToAction("BuyerProfileUpdate");
                }

                if (data != null)
                {
                    DB.BuyerRegistrations.Remove(data);
                    DB.SaveChanges();
                    TempData["BuyerMsg"] = "Record deleted successfully!";
                }
            }

            return View(data);

        }



        [HttpGet]
        public IActionResult BuyerLead(int id)
        {
            var data = (from property in DB.PropertyListings
                        join seller in DB.SellerRegistrations
                        on property.SellerId equals seller.Id
                        where property.Id == id
                        select new
                        {
                            Property = property,
                            Seller = seller
                        }).FirstOrDefault();

            if (data != null)
            {
                ViewBag.PropertyId = data.Property.Id;
                ViewBag.PropertyTitle = data.Property.PropertyTitle;
                ViewBag.PropertyType = data.Property.PropertyType;
                ViewBag.Location = data.Property.Location;
                ViewBag.LocationUrl = data.Property.LocationUrl;
                ViewBag.Price = data.Property.Price;
                ViewBag.Area = data.Property.Area;
                ViewBag.Bedrooms = data.Property.Bedrooms;
                ViewBag.Bathrooms = data.Property.Bathrooms;
                ViewBag.Floors = data.Property.Floors;
                ViewBag.TotalFloors = data.Property.TotalFloors;
                ViewBag.Description = data.Property.Description;
                ViewBag.Photos = data.Property.Photos;
                ViewBag.Sqft = data.Property.Sqft;
                ViewBag.Premium = data.Property.Premium;
                ViewBag.Rera = data.Property.Rera;
                ViewBag.Verified = data.Property.Verified;
                ViewBag.ReraNo = data.Property.ReraNo;
                ViewBag.Certificate = data.Property.Certificate;

                // Seller Information 
                ViewBag.SellerId = data.Seller.Id;
                ViewBag.SellerName = data.Seller.Name;
                ViewBag.SellerMobileNo = data.Seller.MobileNo;
                ViewBag.SellerEmailId = data.Seller.EmailId;
                ViewBag.SellerAddress = data.Seller.Address;
                ViewBag.SellerRegType = data.Seller.RegType;
                ViewBag.SellerReraType = data.Seller.ReraType;
                ViewBag.SellerVerified = data.Seller.Verified;
                ViewBag.SellerReraNo = data.Seller.ReraNo;
                ViewBag.SellerCertificate = data.Seller.Certificate;
            }
            else
            {
                ViewBag.Message = "No Property Found!";
            }

            return View();
        }


        [HttpPost]
        public IActionResult BuyerLead(int id,string txtproprtyid,string txtsellerid, DateTime txtdate)
        {
            var data = (from property in DB.PropertyListings
                        join seller in DB.SellerRegistrations
                        on property.SellerId equals seller.Id
                        where property.Id == id
                        select new
                        {
                            Property = property,
                            Seller = seller
                        }).FirstOrDefault();

            if (data != null)
            {
                ViewBag.PropertyId = data.Property.Id;
                ViewBag.PropertyTitle = data.Property.PropertyTitle;
                ViewBag.PropertyType = data.Property.PropertyType;
                ViewBag.Location = data.Property.Location;
                ViewBag.LocationUrl = data.Property.LocationUrl;
                ViewBag.Price = data.Property.Price;
                ViewBag.Area = data.Property.Area;
                ViewBag.Bedrooms = data.Property.Bedrooms;
                ViewBag.Bathrooms = data.Property.Bathrooms;
                ViewBag.Floors = data.Property.Floors;
                ViewBag.TotalFloors = data.Property.TotalFloors;
                ViewBag.Description = data.Property.Description;
                ViewBag.Photos = data.Property.Photos;
                ViewBag.Sqft = data.Property.Sqft;
                ViewBag.Premium = data.Property.Premium;
                ViewBag.Rera = data.Property.Rera;
                ViewBag.Verified = data.Property.Verified;
                ViewBag.ReraNo = data.Property.ReraNo;
                ViewBag.Certificate = data.Property.Certificate;

                // Seller Information 
                ViewBag.SellerId = data.Seller.Id;
                ViewBag.SellerName = data.Seller.Name;
                ViewBag.SellerMobileNo = data.Seller.MobileNo;
                ViewBag.SellerEmailId = data.Seller.EmailId;
                ViewBag.SellerAddress = data.Seller.Address;
                ViewBag.SellerRegType = data.Seller.RegType;
                ViewBag.SellerReraType = data.Seller.ReraType;
                ViewBag.SellerVerified = data.Seller.Verified;
                ViewBag.SellerReraNo = data.Seller.ReraNo;
                ViewBag.SellerCertificate = data.Seller.Certificate;
            }
            else
            {
                ViewBag.Message = "No Property Found!";
            }


            int maxid = 0;

            if (DB.Leads.Any())
            {
                maxid = DB.Leads.Max(s => s.Id);
            }
            var newid = (maxid == 0) ? 1 : maxid + 1;

            string buyerId = HttpContext.Session.GetString("BuyerId");

            Lead lead = new Lead();
            lead.Id = newid;
            lead.BuyerId = Convert.ToInt32(buyerId);
            lead.PropertyId = Convert.ToInt32(txtproprtyid);
            lead.SellerId = Convert.ToInt32(txtsellerid);
            lead.Date = txtdate;
            lead.Remark = "Pending";

            DB.Leads.Add(lead);
            DB.SaveChanges();

            TempData["LeadMsg"] = "Record Submited successfully!";
            return RedirectToAction("VerifiedProperties");
        }


        //public IActionResult VerifiedViewProperties(string propertyType, int id)
        //{
        //    var data = DB.PropertyListings
        //        .Where(p => p.PropertyType == propertyType && p.Verified == "Yes")
        //        .ToList();

        //    ViewBag.Properties = data;

        //    string buyerId = HttpContext.Session.GetString("BuyerId");

        //    if (!string.IsNullOrEmpty(buyerId))
        //    {
        //        int buyerIntId = Convert.ToInt32(buyerId);

        //        **Check if the lead already exists * *
        //       bool leadExists = DB.Leads.Any(l => l.BuyerId == buyerIntId && l.PropertyId == id);

        //        if (!leadExists) // **Prevent duplicate insertion**
        //        {
        //            int maxid = DB.Leads.Any() ? DB.Leads.Max(s => s.Id) : 0;
        //            var newid = (maxid == 0) ? 1 : maxid + 1;

        //            Lead lead = new Lead
        //            {
        //                Id = newid,
        //                BuyerId = buyerIntId,
        //                PropertyId = id,
        //                Remark = "Pending"
        //            };

        //            DB.Leads.Add(lead);
        //            DB.SaveChanges();
        //            TempData["LeadMsg"] = "Properties successfully applied!";
        //        }
        //        else
        //        {
        //            TempData["LeadMsg"] = "You have already applied for this property.";
        //        }
        //    }

        //    return RedirectToAction("VerifiedViewProperties");
        //} 


        [HttpGet]
        public JsonResult GetEntrySellers()
        {
            var data = DB.SellerRegistrations
              .Select(e => new
              {
                  e.Id,
                  e.Name,
                  e.MobileNo,
                  e.EmailId,
                  e.Address
              }).ToList();
            return Json(data);
        }

        //[HttpGet]
        //public JsonResult GetEntrySellers()
        //{
        //    var data = DB.SellerRegistrations
        //        .Select(e => new
        //        {
        //            e.Id,
        //            Name = e.Name ?? string.Empty,
        //            MobileNo = e.MobileNo ?? string.Empty,
        //            EmailId = e.EmailId ?? string.Empty,
        //            Address = e.Address ?? string.Empty
        //        }).ToList();
        //    return Json(data);
        //}



        [HttpGet]
        public IActionResult Contact()
        {
            int maxid = 0;

            if (DB.Contacts.Any())
            {
                maxid = DB.Contacts.Max(s => s.Id);
            }
            var newid = (maxid == 0) ? 1 : maxid + 1;

            return View();
        }

        [HttpPost]
        public IActionResult Contact(int id, string txtid, string txtdescription, DateTime txtdate )
        {
            int maxid = 0;

            if (DB.Contacts.Any())
            {
                maxid = DB.Contacts.Max(s => s.Id);
            }
            var newid = (maxid == 0) ? 1 : maxid + 1;

            string buyerId = HttpContext.Session.GetString("BuyerId");  

            Contact contact = new Contact();
            contact.Id = newid;
            contact.BuyerId=Convert.ToInt32(buyerId); 
            contact.SellerId=Convert.ToInt32(txtid);
            contact.Date = txtdate;
            contact.Description = txtdescription;
            contact.Remark = "Pending";


            DB.Contacts.Add(contact);
            DB.SaveChanges();

            TempData["ContactMsg"] = "Record Submited successfully!";
            return RedirectToAction("Contact");
           // return View();
        }


        [HttpGet]
        public IActionResult ViewBuyerContact()
        {
            var result = from contact in DB.Contacts
                         join buyer in DB.BuyerRegistrations
                         on contact.BuyerId equals buyer.Id into buyerGroup
                         from buyer in buyerGroup.DefaultIfEmpty() // Handle cases where no buyer exists
                         join seller in DB.SellerRegistrations
                         on contact.SellerId equals seller.Id into sellerGroup
                         from seller in sellerGroup.DefaultIfEmpty() // Handle cases where no seller exists
                         select new
                         {
                             ContactId = contact.Id,
                             Description = contact.Description,
                             Date=contact.Date,
                             Remark = contact.Remark,

                             // Buyer Details
                             BuyerId = contact.BuyerId,
                             BuyerName = buyer.Name,
                             BuyerMobile = buyer.MobileNo,
                             BuyerEmail = buyer.EmailId,
                             BuyerAddress = buyer.Address,

                             // Seller Details
                             SellerId = contact.SellerId,
                             SellerName = seller.Name,
                             SellerMobile = seller.MobileNo,
                             SellerEmail = seller.EmailId,
                             SellerAddress = seller.Address,
                             SellerRegType = seller.RegType,
                             SellerVerified = seller.Verified,
                             SellerReraNo = seller.ReraNo,
                             SellerCertificate = seller.Certificate
                         };

            var contactList = result.ToList();
            ViewBag.ContactData = contactList;

            return View();
        }


        [HttpGet]
        public IActionResult Notification()
        {
            int userId = int.Parse(HttpContext.Session.GetString("BuyerId"));

            var leads = (from l in DB.Leads
                         join b in DB.BuyerRegistrations on l.BuyerId equals b.Id
                         join s in DB.SellerRegistrations on l.SellerId equals s.Id
                         join p in DB.PropertyListings on l.PropertyId equals p.Id
                         where l.BuyerId == userId
                         select new
                         {
                             LeadId = l.Id,
                             BuyerName = b.Name,
                             BuyerMobile = b.MobileNo,
                             BuyerEmail = b.EmailId,
                             BuyerAddress = b.Address,
                             SellerName = s.Name,
                             SellerMobile = s.MobileNo,
                             PropertyId = l.PropertyId,
                             PropertyTitle = p.PropertyTitle,
                             PropertyType = p.PropertyType,
                             PropertyLocation = p.Location,
                             Propertyprice = p.Price,
                             PropertyRera = p.Rera,
                             Remark = l.Remark,
                             Date=l.Date
                         }).ToList();

            ViewBag.Leads = leads;
            return View();
        }


        public IActionResult Logout()
        {
            
            HttpContext.Session.Remove("BuyerEmail");
            HttpContext.Session.Remove("BuyerPassword");
            return RedirectToAction("Index", "Home");
            
        }
    }
}
