﻿using System.Data;
using System.Diagnostics;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using real_estate.Models;

namespace real_estate.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly real_estateDBContext DB;
        public HomeController(ILogger<HomeController> logger, real_estateDBContext dB)
        {
            _logger = logger;          
            DB = dB;
        }


        // [HttpGet]
        //public IActionResult ViewProperties(string propertyType)
        //{
        //    var data = DB.PropertyListings.Where(p=>p.PropertyType== propertyType).ToList();

        //    return View();
        //} 



        [HttpGet]
        public IActionResult ViewProperties(string propertyType, string location, string keyword)
        {
            //var data = DB.PropertyListings
            //             .Where(p => p.PropertyType == propertyType)
            //             .ToList();

            //ViewBag.Properties = data;

            var query = DB.PropertyListings.AsQueryable();

            if (!string.IsNullOrEmpty(propertyType))
            {
                query = query.Where(p => p.PropertyType == propertyType);
            }

            if (!string.IsNullOrEmpty(location))
            {
                query = query.Where(p => p.Location == location);
            }

            if (!string.IsNullOrEmpty(keyword))
            {
                query = query.Where(p => p.Price.Contains(keyword) ||
                                         p.PropertyTitle.Contains(keyword) ||
                                         p.Description.Contains(keyword));
            }

            ViewBag.Properties = query.ToList();

            return View(); // Pass data to the view
        }



        [HttpGet]
        public IActionResult Index(string propertyType, string location, string keyword)
        {
            var query = DB.PropertyListings.AsQueryable();

            // Apply Filters from query string
            if (!string.IsNullOrEmpty(propertyType))
            {
                query = query.Where(p => p.PropertyType == propertyType);
            }

            if (!string.IsNullOrEmpty(location))
            {
                query = query.Where(p => p.Location == location);
            }

            if (!string.IsNullOrEmpty(keyword))
            {
                query = query.Where(p => p.PropertyTitle.Contains(keyword) ||
                                       p.Description.Contains(keyword) ||
                                       p.Price.Contains(keyword));
            }

            // Group by PropertyType and count records
            var propertyCounts = query
                .GroupBy(p => p.PropertyType)
                .Select(g => new { PropertyType = g.Key, Count = g.Count() })
                .ToDictionary(x => x.PropertyType, x => x.Count);

            ViewBag.PropertyCounts = propertyCounts;
            ViewBag.SelectedPropertyType = propertyType;
            ViewBag.SelectedLocation = location;
            ViewBag.SearchKeyword = keyword;

            return View();
        }



     //   [HttpGet]
     //   public IActionResult Index()
     //   {
     //       var propertyCounts = DB.PropertyListings
     //.GroupBy(p => new { p.PropertyType })
     //.Select(g => new { PropertyType = g.Key.PropertyType, Count = g.Count() })
     //.ToDictionary(x => x.PropertyType, x => x.Count);


     //       ViewBag.PropertyCounts = propertyCounts;
     //       return View();
     //   }


     //       [HttpPost]
     //   public IActionResult Index(string propertyType, string location, string keyword)
     //   {
     //       var propertyCounts = DB.PropertyListings
     //.GroupBy(p => new { p.PropertyType })
     //.Select(g => new { PropertyType = g.Key.PropertyType, Count = g.Count() })
     //.ToDictionary(x => x.PropertyType, x => x.Count);


     //       if (!string.IsNullOrEmpty(propertyType))
     //       {
     //           propertyCounts = propertyCounts.Where(p => p.Key == propertyType)
     //               .ToDictionary(p => p.Key, p => p.Value);
     //       }

     //       if (!string.IsNullOrEmpty(location))
     //       {
     //           propertyCounts = propertyCounts.Where(p => DB.PropertyListings.Any(pl => pl.PropertyType == p.Key && pl.Location == location))
     //               .ToDictionary(p => p.Key, p => p.Value);
     //       }

     //       if (!string.IsNullOrEmpty(keyword))
     //       {
     //           propertyCounts = propertyCounts.Where(p => DB.PropertyListings.Any(pl => pl.PropertyType == p.Key && pl.Description.Contains(keyword)))
     //               .ToDictionary(p => p.Key, p => p.Value);
     //       }

     //       ViewBag.PropertyCounts = propertyCounts;

     //       return View();
     //   }

        [HttpGet]
        public IActionResult GetNewId()
        {
            int maxid = DB.SellerRegistrations.Any() ? DB.SellerRegistrations.Max(s => s.Id) : 0;
            int newid = maxid + 1;

            return Json(new { newid });
        }
       
        public IActionResult SellerRegistration()
        {
            return View();
        }

        //[HttpPost]
        //public IActionResult SellerRegistration(string txtid, string txtusername, string txtmobile, string txtemail, string txtaddress, string txtpassword, string txtconfirmpassword,string ddltype)
        //{
        //    try
        //    {
        //        // Convert txtid to integer
        //        int newId = Convert.ToInt32(txtid);

        //        //var existingSeller = DB.SellerRegistrations
        //        //               .FirstOrDefault(s => s.MobileNo == txtmobile && s.EmailId == txtemail && s.Name==txtusername);

        //        //if (existingSeller != null)
        //        //{
        //        //    return Json(new { success = false, message = "Seller already registered with this Email or Mobile Number!" });
        //        //}


        //        var existingSeller = DB.SellerRegistrations
        //        .FirstOrDefault(s => s.MobileNo == txtmobile && s.EmailId == txtemail && s.Name == txtusername);

        //        if (existingSeller != null)
        //        {
        //            return Json(new { success = false, message = "This Seller is already registered with the same Email and Mobile number." });
        //        }




        //        // Create a new Registration object
        //        SellerRegistration sellerregistration = new SellerRegistration
        //        {
        //            Id = newId,
        //            Name = txtusername,
        //            MobileNo = txtmobile,
        //            EmailId = txtemail,
        //            Address = txtaddress,
        //            Password = txtpassword,
        //            RegType = ddltype,
        //            ReraType = "No",
        //            Verified = "No",
        //            ReraNo = "No",
        //            Certificate = "No",
        //            SellerPhoto = "No"
        //        };


        //        //var data = DB.SellerRegistrations
        //        //               .Where(model => model.Name == txtusername && model.MobileNo == txtmobile &&  model.EmailId == txtemail)
        //        //               .ToList();

        //        //if (data.Any())
        //        //{
        //        //    TempData["MsgNew"] = "Customer found!";

        //        //    return View();
        //        //}
        //        // Save to database
        //        DB.SellerRegistrations.Add(sellerregistration);
        //        DB.SaveChanges();

        //        // Return success response
        //        return Json(new { success = true, message = "Registration successful!" });
        //    }
        //    catch (Exception ex)
        //    {
        //        // Return error response
        //        return Json(new { success = false, message = "Error: " + ex.Message });
        //    }
        //    return View();
        //}




        //[HttpPost]
        //public IActionResult SellerRegistration(string txtid,string txtusername,string txtmobile,string txtemail,string txtaddress,string txtpassword,string txtconfirmpassword,string ddltype,IFormFile paymentScreenshot)
        //{
        //    try
        //    {
        //        int newId = Convert.ToInt32(txtid);

        //        var existingSeller = DB.SellerRegistrations
        //            .FirstOrDefault(s => s.MobileNo == txtmobile && s.EmailId == txtemail && s.Name == txtusername);

        //        if (existingSeller != null)
        //        {
        //            return Json(new { success = false, message = "Already registered." });
        //        }

        //        string filePath = "";

        //        // ✅ Save Screenshot
        //        if (paymentScreenshot != null)
        //        {
        //            string fileName = Guid.NewGuid() + Path.GetExtension(paymentScreenshot.FileName);
        //            string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/PaymentScreeshot", fileName);

        //            using (var stream = new FileStream(path, FileMode.Create))
        //            {
        //                paymentScreenshot.CopyTo(stream);
        //            }

        //            filePath = "/PaymentScreeshot/" + fileName;
        //        }

        //        SellerRegistration sellerregistration = new SellerRegistration
        //        {
        //            Id = newId,
        //            Name = txtusername,
        //            MobileNo = txtmobile,
        //            EmailId = txtemail,
        //            Address = txtaddress,
        //            Password = txtpassword,
        //            RegType = ddltype,

        //            ReraType = "No",
        //            Verified = "No",
        //            ReraNo = "No",
        //            Certificate = "No",
        //            SellerPhoto = "No",

        //            // ✅ NEW FIELDS
        //            PaymentScreenshot = filePath,
        //            Status = "Pending"
        //        };

        //        DB.SellerRegistrations.Add(sellerregistration);
        //        DB.SaveChanges();

        //        return Json(new { success = true, message = "Registration successful! Waiting for approval." });
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(new { success = false, message = ex.Message });
        //    }
        //}

        [HttpPost]
        public IActionResult SellerRegistration(string txtid,string txtusername,string txtmobile,string txtemail,string txtaddress,string txtpassword,string txtconfirmpassword,string ddltype,IFormFile paymentScreenshot)
        {
            try
            {
                // Convert ID
                int newId = Convert.ToInt32(txtid);

                // Check duplicate seller
                var existingSeller = DB.SellerRegistrations
                    .FirstOrDefault(s => s.MobileNo == txtmobile &&
                                         s.EmailId == txtemail &&
                                         s.Name == txtusername);

                if (existingSeller != null)
                {
                    return Json(new { success = false, message = "Already registered." });
                }

                string fileName = "";

                // ✅ Upload Payment Screenshot
                if (paymentScreenshot != null && paymentScreenshot.Length > 0)
                {
                    // Step 1: Clean Name
                    string cleanName = txtusername.Trim();

                    // Replace spaces with underscore
                    cleanName = System.Text.RegularExpressions.Regex.Replace(cleanName, @"\s+", "_");

                    // Remove special characters (keep letters + underscore)
                    cleanName = new string(cleanName.Where(c => char.IsLetter(c) || c == '_').ToArray());

                    // Step 2: Extension
                    string extension = Path.GetExtension(paymentScreenshot.FileName);

                    // Step 3: Final File Name
                    fileName = $"{newId}_{cleanName}_payment{extension}";

                    // Step 4: Folder Path
                    string folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/PaymentScreenshot");

                    // Create folder if not exists
                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }

                    // Step 5: Full Path
                    string fullPath = Path.Combine(folderPath, fileName);

                    // Save file
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        paymentScreenshot.CopyTo(stream);
                    }
                }

                // ✅ Save Data in DB
                SellerRegistration seller = new SellerRegistration
                {
                    Id = newId,
                    Name = txtusername,
                    MobileNo = txtmobile,
                    EmailId = txtemail,
                    Address = txtaddress,
                    Password = txtpassword,
                    RegType = ddltype,

                    ReraType = "No",
                    Verified = "No",
                    ReraNo = "No",
                    Certificate = "No",
                    SellerPhoto = "No",

                    // ONLY filename saved (NOT path)
                    PaymentScreenshot = fileName,

                    Status = "Pending"
                };

                DB.SellerRegistrations.Add(seller);
                DB.SaveChanges();

                return Json(new
                {
                    success = true,
                    message = "Registration successful! Waiting for admin approval."
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    message = "Error: " + ex.Message
                });
            }
        }




        //public IActionResult SellerLogin()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public IActionResult SellerLogin([FromForm] string txtlemail, string txtlpassword,string ddltype)
        //{
        //    //var data = DB.Registrations.SingleOrDefault(model => model.Email == txtlemail && model.Password == txtlpassword);
        //    var data = DB.SellerRegistrations.FirstOrDefault(model => model.EmailId == txtlemail && model.Password == txtlpassword && model.RegType== ddltype);
        //    if (data != null)
        //    {
        //        HttpContext.Session.SetString("Id", data.Id.ToString());
        //        HttpContext.Session.SetString("UserName", data.Name);
        //        HttpContext.Session.SetString("SellerEmail", txtlemail);
        //        HttpContext.Session.SetString("SellerPassword", txtlpassword);
        //        return Json(new { success = true });
        //    }
        //    else
        //    {
        //        return Json(new { success = false, message = "Invalid Username or Password!" });
        //    }
        //}

        [HttpPost]
        public IActionResult SellerLogin([FromForm] string txtlemail, string txtlpassword, string ddltype)
        {
            var data = DB.SellerRegistrations
                .FirstOrDefault(model => model.EmailId == txtlemail
                                      && model.Password == txtlpassword
                                      && model.RegType == ddltype);

            if (data != null)
            {
                // ✅ Check Status
                if (data.Status != "Done")
                {
                    return Json(new
                    {
                        success = false,
                        message = "Admin has not verified your account yet. Please wait for approval."
                    });
                }

                // ✅ Login Success
                HttpContext.Session.SetString("Id", data.Id.ToString());
                HttpContext.Session.SetString("UserName", data.Name);
                HttpContext.Session.SetString("SellerEmail", txtlemail);

                return Json(new { success = true });
            }
            else
            {
                return Json(new
                {
                    success = false,
                    message = "Invalid Email or Password!"
                });
            }
        }

        [HttpGet]
        public IActionResult GetBuyerNewId()
        {
            int maxid = DB.BuyerRegistrations.Any() ? DB.BuyerRegistrations.Max(s => s.Id) : 0;
            int newbuyerid = maxid + 1;
           
            return Json(new { newbuyerid });
        }


        public IActionResult BuyerRegistration(string txtbuyerid, string txtusername, string txtmobile, string txtemail, string txtaddress, string txtpassword, string txtconfirmpassword)
        {

            try
            {
                var existingUser = DB.BuyerRegistrations
                .FirstOrDefault(u => u.MobileNo == txtmobile && u.EmailId == txtemail && u.Name== txtusername);

                if (existingUser != null)
                {
                    return Json(new { success = false, message = "This Buyer is already registered with the same Email and Mobile number." });
                }


                // Convert txtid to integer
                int newId = Convert.ToInt32(txtbuyerid);

                // Create a new Registration object
                BuyerRegistration buyerregistration = new BuyerRegistration
                {
                    Id = newId,
                    Name = txtusername,
                    MobileNo = txtmobile,
                    EmailId = txtemail,
                    Address = txtaddress,
                    Password = txtpassword,
                    BuyerPhoto = "NO"
                };

                // Save to database
                DB.BuyerRegistrations.Add(buyerregistration);
                DB.SaveChanges();

                // Return success response
                return Json(new { success = true, message = "Registration successful!" });
            }
            catch (Exception ex)
            {
                // Return error response
                return Json(new { success = false, message = "Error: " + ex.Message });
            }
            return View();
        }

        [HttpPost]
        public IActionResult BuyerLogin([FromForm] string txtBuyerEmail, string txtBuyerPassword)
        {
            //var data = DB.Registrations.SingleOrDefault(model => model.Email == txtlemail && model.Password == txtlpassword);
            var data = DB.BuyerRegistrations.FirstOrDefault(model => model.EmailId == txtBuyerEmail && model.Password == txtBuyerPassword);
            if (data != null)
            {
                HttpContext.Session.SetString("BuyerId", data.Id.ToString());
                HttpContext.Session.SetString("BuyerEmail", txtBuyerEmail);
                HttpContext.Session.SetString("BuyerPassword", txtBuyerPassword);
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, message = "Invalid Username or Password!" });
            }
        }

        [HttpPost]
        public IActionResult AdminLogin([FromForm] string txtAdminName, string txtAdminPassword)
        {
            var data = DB.AdminLogins.FirstOrDefault(model => model.AdminName == txtAdminName && model.AdminPassword == txtAdminPassword);
            if (data != null)
            {
                HttpContext.Session.SetString("AdminName", txtAdminName);
                HttpContext.Session.SetString("AdminPassword", txtAdminPassword);
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, message = "Invalid Username or Password!" });
            }
        }


        [HttpPost]
        public IActionResult AdminAssociationLogin([FromForm] string txtAdminAssoName, string txtAdminAssoPassword)
        {

            var data = DB.AssociationAdmins.FirstOrDefault(model => model.AdminName == txtAdminAssoName && model.AdminPassward == txtAdminAssoPassword);
            if (data != null)
            {
                HttpContext.Session.SetString("AdminAssoName", txtAdminAssoName);
                HttpContext.Session.SetString("AdminAssoPassword", txtAdminAssoPassword);
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, message = "Invalid Username or Password!" });
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }


        //[HttpPost]
        //public IActionResult ViewAllProperties()
        //{
        //    var data = DB.PropertyListings
        //        .GroupBy(p => p.PropertyType)
        //        .Select(g => new { PropertyType = g.Key, Count = g.Count() })
        //        .OrderBy(p => p.PropertyType)
        //        .ToList();

        //    // Define constant property types
        //    string[] propertyTypes = { "Apartment", "House", "Villa", "Townhouse", "Office", "Building", "Shop", "Restaurant" };

        //    // Initialize counts for each property type
        //    var propertyCounts = propertyTypes.ToDictionary(pt => pt, pt => 0);

        //    // Update counts from database
        //    foreach (var item in data)
        //    {
        //        if (propertyCounts.ContainsKey(item.PropertyType))
        //        {
        //            propertyCounts[item.PropertyType] = item.Count;
        //        }
        //    }

        //    ViewBag.PropertyCounts = propertyCounts;
        //    return View();
        //}

        //[HttpPost]
        //public IActionResult ViewAllProperties(string propertyType, string location, string keyword)
        //{
        //    var data = DB.PropertyListings
        //        .Where(p => (string.IsNullOrEmpty(propertyType) || p.PropertyType == propertyType)
        //                    && (string.IsNullOrEmpty(location) || p.Location == location)
        //                    && (string.IsNullOrEmpty(keyword) || p.Description.Contains(keyword)))
        //        .GroupBy(p => p.PropertyType)
        //        .Select(g => new { PropertyType = g.Key, Count = g.Count() })
        //        .OrderBy(p => p.PropertyType)
        //        .ToList();

        //    // Define constant property types
        //    string[] propertyTypes = { "Apartment", "House", "Villa", "Townhouse", "Office", "Building", "Shop", "Restaurant" };

        //    // Initialize counts for each property type
        //    var propertyCounts = propertyTypes.ToDictionary(pt => pt, pt => 0);

        //    // Update counts from database
        //    foreach (var item in data)
        //    {
        //        if (propertyCounts.ContainsKey(item.PropertyType))
        //        {
        //            propertyCounts[item.PropertyType] = item.Count;
        //        }
        //    }

        //    ViewBag.PropertyCounts = propertyCounts;
        //    return View();
        //}

        //public IActionResult ViewAllProperties()
        //{
        //    var propertyCounts = DB.PropertyListings
        // .GroupBy(p => p.PropertyType)
        // .ToDictionary(g => g.Key, g => g.Count());

        //    if (propertyCounts != null)
        //    {
        //        ViewBag.PropertyCounts = propertyCounts;
        //    }
        //    return View();
        //}

        public IActionResult ViewAllProperties()
        {
            var propertyCounts = DB.PropertyListings
                .GroupBy(p => p.PropertyType)
                .ToDictionary(g => g.Key, g => g.Count());

            // Ensure the dictionary is always initialized to prevent null reference errors
            if (propertyCounts == null)
            {
                propertyCounts = new Dictionary<string, int>();
            }

            return View(propertyCounts);
        }




        public IActionResult Logout()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
